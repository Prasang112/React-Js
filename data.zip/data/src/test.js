


import { Component } from "react";
import data from "./data";
import "./productlist.css";

export default class ProductList extends Component {
    constructor() {
        super();
        this.state = { 
            productList: data,
            title: '',
            image: '',
            brand: '',
            price: ''
        };
    }

    deleteProduct = (index) => {
        const updatedProductList = [...this.state.productList];
        updatedProductList.splice(index, 1);
        this.setState({ productList: updatedProductList });
    }

    editProduct = (index) => {
        let product = this.state.productList[index];
        this.setState({
            title: product.title,
            image: product.thumbnail,
            brand: product.brand,
            price: product.price
        });
    }

    handleInputChange = (event) => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    render() {
        return (
            <>
                <div id="productlist">
                <h1 className="H1">Product List Component</h1>
                <hr />
                <table className="table">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Brand</th>
                            <th>Price</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.productList.map((product, index) => <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{product.title}</td>
                            <td><img src={product.thumbnail} width="100px" height="100px" /></td>
                            <td>{product.brand}</td>
                            <td>{product.price}</td>
                            <td><button onClick={() => this.editProduct(index)} className="btn btn-success">Edit</button></td>
                            <td><button onClick={() => this.deleteproduct(index)} className="btn btn-danger">Delete</button></td>
                        </tr>)}
                    </tbody>
                </table>

                </div>

                <div className="d-none" id="login-box">
                    <div className="login-box">
                        <form id="editform">
                            <div className="user-box">
                                <input type="text" id="title" value={this.state.title} onChange={this.handleInputChange} />
                                <label>Title</label>
                            </div>
                            <div className="user-box">
                                <input type="file" id="image" value={this.state.image} onChange={this.handleInputChange} />
                                <label>Image</label>
                            </div>
                            <div className="user-box">
                                <input type="text" id="brand" value={this.state.brand} onChange={this.handleInputChange} />
                                <label>Brand</label>
                            </div>
                            <div className="user-box">
                                <input type="text" id="price" value={this.state.price} onChange={this.handleInputChange} />
                                <label>Price</label>
                            </div>
                            <center>
                                <button type="submit">SEND</button>
                            </center>
                        </form>
                    </div>
                </div>
            </>
        );
    }
}