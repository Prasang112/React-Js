
import { Component } from "react";
import data from "./data";
import "./productlist.css";
export default class ProductList extends Component {
    constructor() {
        super();
        this.state = { productList: data }
        
    }

    deleteproduct = (index) => {
        const updateProductList = [...this.state.productList]
        updateProductList.splice(index, 1);
        this.setState({ productList: updateProductList });
    }

    editProduct = (index) => {
        let productobj = document.getElementById("productlist");
        productobj.className = "d-none";

        let formobj = document.getElementById("login-box");
        formobj.className = "d-block";

    }

    send = ()=>{
        let title = document.getElementById("title").value
        let image = document.getElementById("image").value;
        let brand = document.getElementById("brand").value;
        let price = document.getElementById("price").value;
    }



    render() {
        let productList = data;
        return <>
            <div id="productlist">
                <h1 className="H1">Product List Component</h1>
                <hr />
                <table className="table">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Brand</th>
                            <th>Price</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.productList.map((product, index) => <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{product.title}</td>
                            <td><img src={product.thumbnail} width="100px" height="100px" /></td>
                            <td>{product.brand}</td>
                            <td>{product.price}</td>
                            <td><button onClick={() => this.editProduct(index)} className="btn btn-success">Edit</button></td>
                            <td><button onClick={() => this.deleteproduct(index)} className="btn btn-danger">Delete</button></td>
                        </tr>)}
                    </tbody>
                </table>

            </div>

            <div className="d-none" id="login-box" >
                <div className="login-box" >

                    <form id="editform">
                        <div class="user-box" >
                            <input type="text" id="title" />
                            <label>Title</label>
                        </div>
                        <div class="user-box">
                            <input type="file" id="image" />
                            <label>Image</label>
                        </div>
                        <div class="user-box">
                            <input type="text" id="brand" />
                            <label>Brand</label>
                        </div>
                        <div class="user-box">
                            <input type="text" id="price" />
                            <label>Price</label>
                        </div>
                        <center>
                            <a href="#" onClick={this.send()}>
                                SEND
                                <span></span>
                            </a></center>
                    </form>
                </div>
            </div>


        </>
    }
}