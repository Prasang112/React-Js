
import './App.css';
import { Component } from 'react';
import ProductList from './ProductList';
import Header from './Header';

class App extends Component {
  render() {
    return <>
      <Header />
      <ProductList />
    </>
  }
}

export default App;
